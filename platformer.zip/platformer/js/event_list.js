let is_music_playing = false
var keys = {
    spa:{
        pressed:false
    },
    d:{
        pressed:false
    },
    a:{
        pressed:false
    }
}

window.addEventListener('keydown', (event) => {
    if(is_music_playing === false){
        is_music_playing = true
        song.play()
    }
    switch(event.key){
        case  ' ':
            keys.spa.pressed = true
            break
        case 'd':
            keys.d.pressed = true
            break
        case 'a':
            keys.a.pressed = true
            break

    }

})

window.addEventListener('keyup', (event) => {
    switch(event.key){
        case  ' ':
            keys.spa.pressed = false
            break
        case 'd':
            keys.d.pressed = false
            break
        case 'a':
            keys.a.pressed = false
            break

    }

})