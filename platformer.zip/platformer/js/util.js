function collision(object1,object2) {
    return (
        object1.posizzione.y+object1.height >= object2.posizzione.y &&
        object1.posizzione.y <= object2.posizzione.y+object2.height &&
        object1.posizzione.x+object1.width >= object2.posizzione.x &&
        object1.posizzione.x <= object2.posizzione.x+object2.width
    )
}