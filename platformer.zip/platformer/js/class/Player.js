class Player extends Sprite{
    constructor(posit, collisionBl, imagesrc, fR, fB = 8, animations,){
        super(posit,imagesrc,fR,fB)
        this.posizzione = posit
        this.velocity = {
            x:0,
            y:1,
        }

        this.collisionBlocks = collisionBl

        this.lastDr = 'r'
        this.gravity = 1
        this.jmp_buff = 0
        this.hitbox = {
            posizzione: {
                x: this.posizzione.x + 80,
                y: this.posizzione.y + 63,
            },
            width: 105,
            height: 120,
        }

        this.camerabox = {
            posizzione: {
                x: this.posizzione.x,
                y: this.posizzione.y,
            },
            width: 2000,
            height: 100,
        }
        
        this.animations = animations

        for (let key in this.animations){
            const image = new Image()
            image.src = this.animations[key].imagesrc
            this.animations[key].image = image
        }
    }

    switchSprite(key){
        if (this.image === this.animations[key].image) return
        this.image = this.animations[key].image
        this.framerate = this.animations[key].frameR
        this.frBuffer = this.animations[key].fB
    }

    jump(){
        this.jmp_buff--
        if(this.velocity.y === 0){
            this.jmp_buff = 0
            jump_sound.play()
            this.velocity.y = -20
        }
    }

    set_x_velo(desv,dec){
        if (this.velocity.x < desv){
            if(this.velocity.x + dec > desv){
                this.velocity.x = 0
            }else{
                this.velocity.x += dec
            }
        }
        if (this.velocity.x > desv){
            if(this.velocity.x - dec < desv){
                this.velocity.x = 0
            }else{
                this.velocity.x -= dec
            }
        }
    }

    pinCamToL(canvas, camera_x){
        const camerabox_R = this.camerabox.posizzione.x + this.camerabox.width
        if(camerabox_R >= canvas.width + (camera_x*-1)){
            camera_x -= 1
            return this.pinCamToL(canvas, camera_x)
        }
        return camera_x
    }

    pinCamToR(camera_x){
        const camerabox_L = this.camerabox.posizzione.x
        if(camerabox_L <= camera_x*-1){
            if (camera_x < 0){
                camera_x += 1
                return this.pinCamToR(camera_x)
            }
            else return 0
        }
        return camera_x
    }

    update(){
        this.update_hitbox()
        this.update_frame()
        // c.fillStyle = 'rgba(0,0,255,0.2)'
        // c.fillRect(this.camerabox.posizzione.x, this.camerabox.posizzione.y, this.camerabox.width, this.camerabox.height)
        // c.fillStyle = 'rgba(0,255,0,0.2)'
        // c.fillRect(this.posizzione.x, this.posizzione.y, this.width, this.height)
        // c.fillStyle = 'rgba(0,0,255,0.2)'
        // c.fillRect(this.hitbox.posizzione.x, this.hitbox.posizzione.y, this.hitbox.width, this.hitbox.height)
        this.draw()
        this.posizzione.x += this.velocity.x
        this.update_hitbox()
        this.chfocoll()
        this.applyGrav()
        this.update_hitbox()
        this.chfvcoll()
    }

    update_hitbox(){
        this.hitbox = {
            posizzione: {
                x: this.posizzione.x + 80,
                y: this.posizzione.y + 57,
            },
            width: 105,
            height: 125,
        }

        this.camerabox = {
            posizzione: {
                x: this.posizzione.x - 250,
                y: this.posizzione.y,
            },
            width: 800,
            height: 200,
        }
    }

    jump_anim(){
        if(this.velocity.y < 0){
            if (this.lastDr === 'r') this.switchSprite('jump')
            else this.switchSprite('jump_l')
        }
        else if(this.velocity.y > 0){
            if (this.lastDr === 'r') this.switchSprite('fall')
            else this.switchSprite('fall_l')
        }
    }

    chfocoll(){
        for(let x = 0; x < this.collisionBlocks.length; x++){
            const collisionBlock = this.collisionBlocks[x]
            if(collision( this.hitbox,collisionBlock)){
                if (this.velocity.x > 0){
                    this.velocity.x = 0
                    const offset = this.hitbox.posizzione.x - this.posizzione.x + this.hitbox.width
                    this.posizzione.x = collisionBlock.posizzione.x - offset - 0.01
                    break
                }
                if (this.velocity.x < 0){
                    this.velocity.x = 0
                    const offset = this.hitbox.posizzione.x - this.posizzione.x
                    this.posizzione.x = collisionBlock.posizzione.x + collisionBlock.width - offset + 0.01
                    break
                }
            }
        }
    }

    applyGrav(){
        this.velocity.y += this.gravity
        this.posizzione.y += this.velocity.y
    }

    chfvcoll(){
        for(let x = 0; x < this.collisionBlocks.length; x++){
            const collisionBlock = this.collisionBlocks[x]
            if(collision( this.hitbox,collisionBlock)){
                if (this.velocity.y > 0){
                    this.velocity.y = 0
                    const offset = this.hitbox.posizzione.y - this.posizzione.y + this.hitbox.height
                    this.posizzione.y = collisionBlock.posizzione.y - offset - 0.01
                    break
                }
                if (this.velocity.y < 0){
                    const offset = this.hitbox.posizzione.y - this.posizzione.y
                    this.posizzione.y = collisionBlock.posizzione.y + collisionBlock.height - offset + 0.01
                    this.velocity.y = 1
                    break
                }
            }
        }
        
    }
}