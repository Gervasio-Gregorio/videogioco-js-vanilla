class Collision_block{
    constructor({position}){
        this.posizzione = position
        this.width = 16
        this.height = 16
    }

    draw(){
        // c.fillStyle = 'rgba(255, 0, 0, 0.5)'
        // c.fillRect(this.posizzione.x / 2.57142857143, this.posizzione.y / 2.57142857143, this.width, this.height)
    }

    update(){
        this.draw()
    }
}