class Sprite{
    constructor(posit, imagesrc, fR = 1, fB = 1){
        this.framerate = fR
        this.position = posit
        this.image = new Image()
        this.image.onload = () =>{
            this.width = this.image.width / this.framerate
            this.height = this.image.height
            this.loaded = true
        }
        this.image.src = imagesrc
        this.loaded = false
        this.crFrame = 0
        this.frBuffer = fB
        this.elapFr = 0
    }

    draw(){
        if(this.loaded){
            const cropbox = {
                position:{
                    x: this.crFrame * this.width,
                    y: 0,
                },
                width: this.width,
                height: this.height,
            }
            c.drawImage(
                this.image,
                cropbox.position.x,
                cropbox.position.y,
                cropbox.width,
                cropbox.height,
                this.position.x,
                this.position.y,
                this.width,
                this.height
            )

        }
    }

    update(){
        this.draw()
        this.update_frame()
    }
    
    update_frame(){
        this.elapFr++
        if(this.elapFr % this.frBuffer === 0){
            if (this.crFrame < this.framerate - 1) this.crFrame++
            else this.crFrame = 0
        }
    }
}