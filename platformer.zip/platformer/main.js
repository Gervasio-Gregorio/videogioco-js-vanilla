const song = new Audio('./audio/Bring It In, Guys!.mp3')
song.loop = true
const jump_sound = new Audio('./audio/jump.mp3')
const end = new Audio('./audio/winn.mp3')
end.loop = true

let end_swh = false

const canvas = document.querySelector('canvas')
const c = canvas.getContext('2d')

canvas.width = 1024
canvas.height = 576

const collision2D = []
for(let x = 0; x < coll.length; x += 210){
    collision2D.push(coll.slice(x, x + 210))
}

const collisionBlocks = []
collision2D.forEach((row, y) => {
    row.forEach((symbol, x) => {
        if (symbol === 130){
            collisionBlocks.push(
                new Collision_block({
                    position: {
                        x: x * 41.1428571429,
                        y: y * 41.1428571429,
                    },
                })
            )
        }
    })
})

const bklv1 = new Sprite(
    position = {
        x:0,
        y:0
    },
    imagesrc = 'sprite/levels/dungeon_lv.png'
)

const player = new Player(position = {
        x: 100,
        y: 295,
    },
    collisionBlocks,
    imagesrc = './sprite/pg/IDLE.png',
    frameR = 7,
    fB = 8,
    animations = {
        idle: {
            imagesrc: './sprite/pg/IDLE.png',
            frameR: 7,
            fB: 8,
        },
        running: {
            imagesrc: './sprite/pg/RUN.png',
            frameR: 8,
            fB: 5,
        },
        jump: {
            imagesrc: './sprite/pg/JUMP.png',
            frameR: 1,
            fB: 1,
        },
        fall: {
            imagesrc: './sprite/pg/FALL.png',
            frameR: 1,
            fB: 1,
        },
        idle_l: {
            imagesrc: './sprite/pg/IDLE_L.png',
            frameR: 7,
            fB: 8,
        },
        running_l: {
            imagesrc: './sprite/pg/RUN_L.png',
            frameR: 8,
            fB: 5,
        },
        jump_l: {
            imagesrc: './sprite/pg/JUMP_L.png',
            frameR: 1,
            fB: 1,
        },
        fall_l: {
            imagesrc: './sprite/pg/FALL_L.png',
            frameR: 1,
            fB: 1,
        },
    }
)

let camera_x = 0

function movment_update(){
    if(keys.spa.pressed){
        player.jmp_buff = 5
    }
    if(keys.d.pressed && keys.a.pressed){
        if(player.velocity.y === 0){
            player.set_x_velo(0,5)
            if (player.lastDr === 'r') player.switchSprite('idle')
            else player.switchSprite('idle_l')
        }
        else player.jump_anim()
    }
    else if(keys.d.pressed || keys.a.pressed){
        if(keys.d.pressed){
            player.lastDr = 'r'
            if (player.velocity.y === 0 && player.velocity.x === 0) player.switchSprite('idle')
            else if(player.velocity.y === 0 && player.velocity.x != 0) player.switchSprite('running')
            else player.jump_anim()
            player.set_x_velo(10,1)
        }
        if(keys.a.pressed){
            player.lastDr = 'l'
            if (player.velocity.y === 0 && player.velocity.x === 0) player.switchSprite('idle_l')
            else if(player.velocity.y === 0 && player.velocity.x != 0) player.switchSprite('running_l')
            else player.jump_anim()
            player.set_x_velo(-10,1)
        }
    }
    else{
        if(player.velocity.y === 0){
            player.set_x_velo(0,5)
            if (player.lastDr === 'r') player.switchSprite('idle')
            else player.switchSprite('idle_l')
        }
        else player.jump_anim()
    }

    if(player.jmp_buff > 0){
        player.jump()
    }

    if(player.velocity.y === -1){
        player.velocity.y = 0
    }
    
}

const end_img = new Sprite(
    positio= {
        x: 0,
        y: 0,
    },
    imgsrc= './sprite/winn screen/winn.png',
)

function animate(){
    if(player.hitbox.posizzione.x >= 8090){
        if(end_swh != true){
            song.pause()
            end.play()
            end_swh = true
        }
        c.fillStyle = 'rgb(0,0,0)'
        c.fillRect(0,0, canvas.width, canvas.height)
        end_img.update()
        
    }
    else{
        window.requestAnimationFrame(animate)
        c.save()
        c.translate(camera_x, 0)
        c.scale(2.57142857143,2.57142857143)
        bklv1.update()
        collisionBlocks.forEach(collisionBlock => {
            collisionBlock.update()
        })
        c.restore()
        c.save()
        c.translate(camera_x, 0)
        player.update(camera_x,canvas)
        movment_update()
        c.restore()
        camera_x = player.pinCamToL(canvas, camera_x)
        camera_x = player.pinCamToR(camera_x)

        if(player.hitbox.posizzione.y >= canvas.height){
            window.location.reload()
        }
    }
}

animate()